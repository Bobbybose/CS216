/* 
 * File: smartReverse.cpp
 * Purpose: provide the implementation of the smartReverse class
 *
 * Author: Bobby Bose
 *
 */

#include <stack>
#include "smartReverse.h"

// default constructor
smartReverse::smartReverse()
{                                           //Basic Constructor doesn't need anything	
}

// constructor: initialize str with ini_str passing as a parameter
smartReverse::smartReverse(string ini_str)
{
	str=ini_str;                            //Set str equal to parameter
}

// return the current value of the private data member: str
string smartReverse::getString() const
{
	return str;                             //Returning the string holding the word
}

// set the value of str to be the passed in parameter input_str
void smartReverse::setString(string input_str)
{
	str=input_str;                          //Setting str equal to the parameter
}

// return a reversed string from str
// using a loop to implement
// Note that str has not been changed
string smartReverse::rev() const
{
	string temp="";                         //Temporary string variable for answer

	for(int i=str.length()-1; i>=0; i--){   //Cycling through all the characters in str backwards
		temp=temp+str.at(i);                //Adding the current character to the temp variable
	}

	return temp;	                        //Returning the backwards word
}

// return a reversed string from str
// using recursion to implement
// Note that str has not been changed
string smartReverse::rev_recursive() const
{
	if(str=="")                             //If no more characters are left
		return "";                              //Return without another recursion
	return str[str.length()-1]+smartReverse(str.substr(0,str.length()-1)).rev_recursive();
    //This line:
    //1. Creates a new smartReverse object with a string similar to str, but with one less character at the end
    //2. Calls rev_recursive again using this new smartReverse object
    //3. Adds this new value to the end of the current last letter
    //4. Returns the whole solution
}

// return a reversed string from str
// using a stack to implement
// Note that str has not been changed
string smartReverse::rev_stack() const
{
	stack<string> ans;                      //Creating a stack of strings
	string answer="";	                    //Variable for the answer
	string temp="";                         //Variable to temporarily hold the current character
    
	for(int i=0; i<str.length(); i++){      //Cycling through all the characters
		temp=str.at(i);                     //Setting temp equal to the current character
		ans.push(temp);                     //Push temp (current character) onto the stack
	}		

	for(int i=0; i<str.length(); i++){      //Cycling through all the characters
		answer=answer+string(ans.top());    //Adding the top character of the stack onto the end of answer
		ans.pop();                          //Popping the top element off of ans
	}		
	return answer;                          //Returning the backwards string
}


FinalGrade.h- Description of the class named FinalGrade.
FinalGrade.cpp- Implementation of the member functions of the class named FinalGrade.
Gradebook.h- Description of the class named Gradebook.
Gradebook.cpp- Implementation of the member functions of the class named Gradebook.
PA1.cpp- Program with the main function. Gradebook curve calculator for CS216 Finals

Nothing special needed for compiling.
    Just normal g++ FinalGrade.cpp Gradebook.cpp PA1.cpp -o CS216PA1
